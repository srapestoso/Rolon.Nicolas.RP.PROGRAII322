package rp_progra2_322;

public class RobotVigilancia extends Robot implements Diagnosticable {
    private final int cantCamaras;
    private static final int CONSUMO_CAMARA = 4;
    private static final int CONSUMO_BASE = 6;

    public RobotVigilancia(String numeroSerie, String fabricante,Prioridad prioridad, int nivelBateria, int cantCamaras) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        super.validarPositivo(cantCamaras);
        this.cantCamaras = cantCamaras;
    }

    /**
     * Calcula el consumo de bateria del robot
     * @return el nivel de consumo
     */
    @Override
    public int calcularConsumo() {
        return cantCamaras * CONSUMO_CAMARA + CONSUMO_BASE;
    }

    /**
     * Inicia el diagnostico del robot
     * @return un mensaje con el numero de serie y la cantidad de camaras operativas
     */
    @Override
    public String iniciarDiagnostico() {
        return "Diagnostico de vigilancia " + getNumeroSerie() + ": capacidad de " + cantCamaras + " camaras operativas.";
    }
    
    @Override
    public String toString() {
        return "RobotVigilancia"+ super.toString() + "superficie=" + cantCamaras  + ']';
    }
    
}
