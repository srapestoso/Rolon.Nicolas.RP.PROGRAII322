package rp_progra2_322;


public interface Diagnosticable {
    String iniciarDiagnostico();
}
