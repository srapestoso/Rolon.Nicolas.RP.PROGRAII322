package rp_progra2_322;

import java.util.Objects;

public abstract class Robot {
    private final String numeroSerie;
    private final String fabricante;
    private final Prioridad prioridad;
    private int nivelBateria;
    private static final int NIVEL_MAX = 100;
    private static final int NIVEL_MIN = 0;

    /**
     * Constructor de la clase Robot
     * @param numeroSerie unico del robot
     * @param fabricante del robot
     * @param prioridad del servicio
     * @param nivelBateria del robot
     */
    public Robot(String numeroSerie, String fabricante, Prioridad prioridad, int nivelBateria) {
        this.numeroSerie = numeroSerie;
        this.fabricante = fabricante;
        this.nivelBateria = nivelBateria;
        this.prioridad = prioridad;
    }

    /**
     * obtiene la prioridad del robot
     * @return la prioridad
     */
    public Prioridad getPrioridad() {
        return prioridad;
    }   
    
    /**
     * Setea el nivel de bateria en el robot
     * @param nivel a setear en el robot
     */
    public void setNivelBateria(int nivel){
        if( nivel < NIVEL_MIN || nivel > NIVEL_MAX ){
            throw new IllegalArgumentException("Nivel de bateria invalido");
        }
        this.nivelBateria = nivel;
    }

    /**
     * Obtiene el numero de serie del robot
     * @return numero de serie
     */
    public String getNumeroSerie() {
        return numeroSerie;
    }

    /**
     * Obtiene el nombre del fabricante
     * @return nombre del fabricante
     */
    public String getFabricante() {
        return fabricante;
    }
    
    /**
     * Obtiene el nivel de bateria
     * @return nivel de bateria
     */
    public int getNivelBateria() {
        return nivelBateria;
    }
    
    /**
     * Calcula el consumo del robot
     * @return el consumo de bateria
     */
    public abstract int calcularConsumo();
    
    /**
     * Validador de datos positivos para la clase robot
     * @param dato a validar
     */
    protected void validarPositivo(int dato){
        if(dato < 0){
            throw new IllegalArgumentException("Dato invalido");
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroSerie , fabricante);
    }

    @Override
    public boolean equals(Object o) {
        boolean respuesta = false;
        if(o == null){
            respuesta = false;
        }
        if(o instanceof Robot){
            respuesta = numeroSerie.equals(((Robot) o).numeroSerie) && fabricante.equals(((Robot) o).fabricante);
        }
        
        return respuesta;
    }

    @Override
    public String toString() {
        return " [" + "numeroSerie=" + numeroSerie + ", fabricante=" + fabricante + ", prioridad=" + prioridad + ", nivelBateria=" + nivelBateria;
    }
    
    
}
