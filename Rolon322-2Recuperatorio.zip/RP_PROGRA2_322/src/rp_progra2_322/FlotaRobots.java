package rp_progra2_322;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class FlotaRobots {
    private final String nombre;
    private final List<Robot> robots;

    public FlotaRobots(String nombre) {
        this.nombre = nombre;
        this.robots = new ArrayList<>();
    }
    
    /**
     * Agregar un robot a la lista siempre y cuando no exista ya uno igual
     * @param r robot a agregar a la lista
     * @throws RobotDuplicadoException cuando un robot ya se encuentra en la lista
     */
    public void agregarRobot(Robot r) throws RobotDuplicadoException{
        Objects.requireNonNull(r);
        if(robots.contains(r)){
            throw new RobotDuplicadoException("No se pudo agregar: Ya existe un robot " + r.getNumeroSerie() + " y fabricante " + r.getFabricante());
        }
        robots.add(r);
    }
    
    /**
     * Obtiene la lista de robots en una nueva
     * @return copia de la lista nueva de robots
     */
    public List<Robot> obtenerRobots(){
        return new ArrayList<>(robots);
    }
    
    /**
     * Devuelve una lista nueva segun el criterio dado
     * @param p criterio a considerar para la nueva lista
     * @return una lista nueva con el criterio establecido por parametro
     */
    public List<Robot> filtrarPorPrioridad(Prioridad p){
        Objects.requireNonNull(p);
        List<Robot> nuevaLista = new ArrayList<>();
        
        for (Robot r : robots) {
            if(r.getPrioridad().equals(p)){
                nuevaLista.add(r);
            }
        }        
        return nuevaLista;
    }
    
    /**
     * Filtra en una lista nueva los robots segun el consumo recibido por parametro
     * @param consMax consumo a considerar para la lista nueva
     * @return una lista nueva con el criterio establecido por parametro
     */
    public List<Robot> obtenerRobotsConConsumoMaximo(int consMax){
        
        List<Robot> nuevaLista = new ArrayList<>();
        
        for (Robot r : robots) {
            if(r.calcularConsumo() <= consMax){
                nuevaLista.add(r);
            }
        }
        
        return nuevaLista;
    }
    
}
