package rp_progra2_322;


public class RobotDuplicadoException extends Exception {

    public RobotDuplicadoException(String string) {
        super(string);
    }
    
}
