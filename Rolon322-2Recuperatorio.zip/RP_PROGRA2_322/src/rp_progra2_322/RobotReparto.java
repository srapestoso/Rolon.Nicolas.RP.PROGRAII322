package rp_progra2_322;

public class RobotReparto extends Robot implements Ejecutable, Diagnosticable {
    private final int capCarga;
    private static final int CONSUMO_KG = 3;
    private static final int CONSUMO_BASE = 4;

    public RobotReparto(String numeroSerie, String fabricante,Prioridad prioridad, int nivelBateria,int capCarga) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        super.validarPositivo(capCarga);
        this.capCarga = capCarga;
    }

    /**
     * Calcula el consumo de bateria del robot
     * @return el nivel de consumo
     */
    @Override
    public int calcularConsumo() {
        return capCarga * CONSUMO_KG + CONSUMO_BASE;
    }

    /**
     * Inicia el servicio del robot siempre y cuando el consumo no agote la bateria del robot
     * @return Un mensaje con el numero de serie y la bateria restante
     */
    @Override
    public String iniciarServicio() {
        int consumo = calcularConsumo();
        
        if (getNivelBateria() < consumo){
            throw new IllegalStateException("No se pudo ejecutar " + getNumeroSerie() + ": bateria insuficiente.");
        }
        
        setNivelBateria(getNivelBateria() - consumo);
        
        return "Servicio de reparto " + getNumeroSerie() + " ejecutado. Bateria restante: " + getNivelBateria() + "%. ";
    }

    /**
     * Inicia el diagnostico del robot
     * @return un mensaje con el numero de serie y la cantidad de camaras operativas
     */
    @Override
    public String iniciarDiagnostico() {
        return "Diagnostico de reparto " + getNumeroSerie() + ": capacidad de " + capCarga + " kg.";
    }
    
    @Override
    public String toString() {
        return "RobotReparto"+ super.toString() + "superficie=" + capCarga  + ']';
    }
    
}
