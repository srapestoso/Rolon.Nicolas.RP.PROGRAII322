package rp_progra2_322;

public enum Prioridad {
    BAJA,
    MEDIA,
    ALTA
}
