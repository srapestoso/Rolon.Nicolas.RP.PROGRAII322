package rp_progra2_322;

public class RobotLimpieza extends Robot implements Ejecutable {
    private final int superficie;
    private static final int DIVISOR = 10;
    private static final int CONSUMO_BASE = 5;

    public RobotLimpieza(String numeroSerie, String fabricante,Prioridad prioridad, int nivelBateria, int superficie) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        super.validarPositivo(superficie);
        this.superficie = superficie;
    }    
    
    /**
     * Calcula el consumo de bateria del robot
     * @return el nivel de consumo
     */
    @Override
    public int calcularConsumo() {
        return superficie / DIVISOR + CONSUMO_BASE;
    }

    /**
     * Inicia el servicio del robot siempre y cuando el consumo no agote la bateria del robot
     * @return Un mensaje con el numero de serie y la bateria restante
     */
    @Override
    public String iniciarServicio() {
        int consumo = calcularConsumo();
        
        if (getNivelBateria() < consumo){
            throw new IllegalStateException("No se pudo ejecutar " + getNumeroSerie() + ": bateria insuficiente.");
        }
        
        setNivelBateria(getNivelBateria() - consumo);
        
        return "Servicio de limpieza " + getNumeroSerie() + " ejecutado. Bateria restante: " + getNivelBateria() + "%. ";        
    }

    @Override
    public String toString() {
        return "RobotLimpieza"+ super.toString() + "superficie=" + superficie  + ']';
    }
    
    
}
