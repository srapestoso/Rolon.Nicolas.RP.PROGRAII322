package rp_progra2_322;


public interface Ejecutable {
    
    String iniciarServicio();
    
}
